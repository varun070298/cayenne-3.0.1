package test;

import test.auto._Trade;

public class Trade extends _Trade {

}
