package test;

import test.auto._TradeInfo;

public class TradeInfo extends _TradeInfo {

}
