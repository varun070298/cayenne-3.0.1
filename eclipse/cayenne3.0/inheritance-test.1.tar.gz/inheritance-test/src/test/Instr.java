package test;

import test.auto._Instr;

public class Instr extends _Instr {

}
