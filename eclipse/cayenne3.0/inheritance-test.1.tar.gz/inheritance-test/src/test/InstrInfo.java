package test;

import test.auto._InstrInfo;

public class InstrInfo extends _InstrInfo {

}
