package test;

import test.auto._BaseEntity;

public class BaseEntity extends _BaseEntity {

}
