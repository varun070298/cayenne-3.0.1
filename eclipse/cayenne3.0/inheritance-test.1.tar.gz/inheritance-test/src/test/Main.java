package test;

import java.util.Arrays;
import java.util.List;

import org.apache.cayenne.ObjectContext;
import org.apache.cayenne.access.DataContext;
import org.apache.cayenne.query.SelectQuery;

public class Main {

	public static void main(String[] args) {

		ObjectContext c = DataContext.createDataContext();

		Instr i1 = c.newObject(Instr.class);
		InstrInfo ii1 = c.newObject(InstrInfo.class);
		ii1.setAttribute("ia1");
		i1.setInstr(ii1);

		Trade t1 = c.newObject(Trade.class);
		TradeInfo ti1 = c.newObject(TradeInfo.class);
		ti1.setAttribute("ta1");
		t1.setTradeInfo(ti1);

		c.commitChanges();

		// before testing select, let's remove objects from memory
		c.invalidateObjects(Arrays.asList(i1, ii1, t1, ti1));

		SelectQuery q = new SelectQuery(BaseEntity.class);
		List<BaseEntity> results = c.performQuery(q);

		for (BaseEntity result : results) {

			String attribute = null;
			if (result instanceof Instr) {
				attribute = ((Instr) result).getInstr().getAttribute();
			} else {
				attribute = ((Trade) result).getTradeInfo().getAttribute();
			}

			System.out.println(String.format("ID: %s, type: %s, attribute: %s",
					result.getObjectId(), result.getClass().getName(),
					attribute));
		}
	}
}
